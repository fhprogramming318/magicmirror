<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Email-PHP</title>
</head>
<body>
<?php
  require_once("emailreader.php");


  $er = new EmailReader();
  print_r($er->GetMessage(1));
  echo br.br;

  echo "There are" .$er->GetInboxCount()." messages";

  for($i=0; $i<$er->GetInboxCount(); $i++){
    echo br.br;
    echo "<h3>Message received from:</h3>". $er->GetMessage($i)['header']->fromaddress;
    echo br.br;
    echo "<h3>Message received on:</h3>". $er->GetMessage($i)['header']->date;
    echo br.br;
    echo "<h3>Subject:</h3>". $er->GetMessage($i)['header']->subject;
    echo "<h3>Message in text format</h3>". $er->GetMessage($i)['body_text'];
    echo "<h3>Message in html format</h3>". $er->GetMessage($i)['body_html'];
    echo "*********************************************************************";
  }

  $er->close();
  echo br.br;
 ?>
</body>
</html>
