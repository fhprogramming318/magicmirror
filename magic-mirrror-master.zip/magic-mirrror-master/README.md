# Magic-Mirrror
Project for Software-Development 2nd semester

# Goal
Develop a Website which is able to display informations about current weather, E-Mail, News and Clock